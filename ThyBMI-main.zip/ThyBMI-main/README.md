# BMI_Calculator
WebApp to calculate BMI
